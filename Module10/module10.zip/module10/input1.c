#include<stdio.h>
int main(){
     int a;
     float b;
     printf( "Enter an int and a float: ");
     scanf( "%d%f", &a, &b);
     printf( "Their product = %g\n",a*b);
     return 0;      
}
