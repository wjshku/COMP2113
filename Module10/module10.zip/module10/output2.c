#include <stdio.h>
int main(){
     char name[] = "Alan";
     int age = 20;
     float weight = 60.5;
     printf( "%s is %d years old and weights %g kg\n",name, age, weight );
     return 0;
}
